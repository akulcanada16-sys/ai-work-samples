import importlib.util
import json
import subprocess
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TOOL = ROOT / "dialogue_csv_check.py"
FIXTURES = ROOT / "tests" / "fixtures"
REPORT = ROOT / "tests" / "report-for-test.json"
SPEC = importlib.util.spec_from_file_location("dialogue_csv_check", TOOL)
assert SPEC and SPEC.loader
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)


def run(*args: str) -> subprocess.CompletedProcess[str]:
    return subprocess.run([sys.executable, str(TOOL), *args], text=True, capture_output=True, cwd=ROOT, check=False)


class DialogueCsvCheckTests(unittest.TestCase):
    def tearDown(self):
        REPORT.unlink(missing_ok=True)

    def test_bom_quoted_comma_and_multiline_are_clean(self):
        result = run(str(FIXTURES / "bom_multiline.csv"))
        self.assertEqual(result.returncode, 0, result.stderr + result.stdout)
        self.assertIn("CLEAN", result.stdout)

    def test_duplicate_ids_blank_translation_and_placeholder_mismatch(self):
        result = run(str(FIXTURES / "issues.csv"))
        self.assertEqual(result.returncode, 1)
        self.assertIn("placeholder_mismatch", result.stdout)
        self.assertIn("duplicate_id", result.stdout)
        self.assertIn("blank_translation", result.stdout)

    def test_escaped_placeholders_are_ignored(self):
        result = run(str(FIXTURES / "escaped.csv"))
        self.assertEqual(result.returncode, 0, result.stdout)

    def test_placeholder_occurrence_counts_must_match(self):
        result = run(str(FIXTURES / "placeholder-count.csv"))
        self.assertEqual(result.returncode, 1)
        self.assertIn("placeholder_mismatch", result.stdout)

    def test_duplicate_headers_stop_column_based_checks(self):
        result = run(str(FIXTURES / "duplicate-headers.csv"))
        self.assertEqual(result.returncode, 1)
        self.assertIn("duplicate_header", result.stdout)
        self.assertNotIn("blank_translation", result.stdout)

    def test_ragged_row_and_multiline_start_line(self):
        result = run(str(FIXTURES / "ragged.csv"))
        self.assertEqual(result.returncode, 1)
        self.assertIn("line 4: ragged_row", result.stdout)

    def test_malformed_quotes_are_reported_as_issue(self):
        result = run(str(FIXTURES / "malformed.csv"))
        self.assertEqual(result.returncode, 1)
        self.assertIn("malformed_csv", result.stdout)

    def test_file_and_row_limits_are_clear_read_errors(self):
        source = FIXTURES / "issues.csv"
        old_bytes, old_rows = MODULE.MAX_BYTES, MODULE.MAX_DATA_ROWS
        try:
            MODULE.MAX_BYTES = 1
            with self.assertRaisesRegex(OSError, "limit"):
                MODULE.read_and_check(source, "id", "en", None)
            MODULE.MAX_BYTES = old_bytes
            MODULE.MAX_DATA_ROWS = 1
            with self.assertRaisesRegex(OSError, "data rows"):
                MODULE.read_and_check(source, "id", "en", None)
        finally:
            MODULE.MAX_BYTES, MODULE.MAX_DATA_ROWS = old_bytes, old_rows

    def test_large_valid_cell_within_file_limit_is_supported(self):
        result = run(str(FIXTURES / "large-cell.csv"))
        self.assertEqual(result.returncode, 0, result.stderr + result.stdout)

    def test_json_output_refuses_source_and_writes_safe_report(self):
        source = FIXTURES / "clean.csv"
        unsafe = run(str(source), "--json-output", str(source))
        self.assertEqual(unsafe.returncode, 2)
        self.assertIn("must not be the input", unsafe.stderr)
        safe = run(str(source), "--json-output", str(REPORT))
        self.assertEqual(safe.returncode, 0, safe.stderr)
        self.assertEqual(json.loads(REPORT.read_text(encoding="utf-8"))["issues"], [])
        existing = run(str(source), "--json-output", str(REPORT))
        self.assertEqual(existing.returncode, 2)
        self.assertIn("existing paths are refused", existing.stderr)

    def test_explicit_locale_and_missing_configured_column(self):
        source = FIXTURES / "columns.csv"
        only_fr = run(str(source), "--locale-columns", "fr")
        self.assertEqual(only_fr.returncode, 0)
        missing = run(str(source), "--locale-columns", "it")
        self.assertEqual(missing.returncode, 1)
        self.assertIn("missing_column", missing.stdout)


if __name__ == "__main__":
    unittest.main()
