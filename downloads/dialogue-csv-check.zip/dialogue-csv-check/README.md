# Dialogue CSV Check

A dependency-free Python 3.10+ command-line checker for game dialogue and localization CSV files. It **only reads** the input CSV; it never repairs, rewrites, executes, or uploads CSV content.

## Quick start

```powershell
python dialogue_csv_check.py examples/dialogue-clean.csv
python dialogue_csv_check.py examples/dialogue-flawed.csv
python dialogue_csv_check.py examples/dialogue-clean.csv --locale-columns fr,es --json-output report.json
```

Exit codes: **0** no issues, **1** validation issues found, **2** invalid options, read/decode errors, file limit, or unsafe report path.

## Checks

- empty or repeated headers
- missing configured `id`, source, or explicit locale columns
- malformed CSV quoting and rows with a different number of cells than the header
- blank or duplicate IDs
- blank locale cells
- mismatched simple named placeholder **occurrence counts** between source and each locale, such as `{player_name}` or `{count}`

By default `id` is the ID column, `en` is the source column, and every other header is a locale column. Use `--locale-columns fr,de` to check only named locale columns.

### Placeholder grammar

The checker recognizes only `{name}` where `name` starts with a letter or underscore and then contains letters, digits, or underscores. It compares each name and its number of appearances: `{name} {name}` does not match `{name}`. Escaped double braces such as `{{name}}` are intentionally ignored. It does not parse printf tokens, positional/format-specifier placeholders, nested braces, ICU MessageFormat, or advanced Python formatting.

## Limits and line numbers

Input must be a regular file up to 10 MiB and at most 100,000 data rows. UTF-8 and UTF-8 with BOM are supported. Python's standard `csv` parser supports quoted commas, CRLF, and quoted multi-line cells; its field limit is raised to the same 10 MiB file cap, so valid cells within the file cap are supported. Reported row lines are physical source-start lines calculated from the parser's consumed physical line count; a malformed final record can only be located at the line where parser failure was reported.

`--json-output` creates a new report only. It refuses the input path, including an existing hard link or resolved symlink to the input, and refuses every existing output path rather than overwriting it. It does not modify the source CSV.

## Tests

```powershell
python -m unittest discover -s tests -v
```

AI agents wrote and tested this tool; no human-review claim is made.
