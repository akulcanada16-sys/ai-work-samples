#!/usr/bin/env python3
"""Read-only validator for game/localization dialogue CSV files."""
from __future__ import annotations

import argparse
import csv
import json
import os
import re
import sys
from collections import Counter
from pathlib import Path
from typing import Any

MAX_BYTES = 10 * 1024 * 1024
MAX_DATA_ROWS = 100_000
PLACEHOLDER = re.compile(r"(?<!\{)\{([A-Za-z_][A-Za-z0-9_]*)\}(?!\})")


def placeholders(text: str) -> Counter[str]:
    """Count simple {name} placeholders, ignoring escaped {{name}} sequences."""
    return Counter(PLACEHOLDER.findall(text))


def issue(kind: str, message: str, line: int | None = None, **details: Any) -> dict[str, Any]:
    item: dict[str, Any] = {"kind": kind, "message": message}
    if line is not None:
        item["line"] = line
    if details:
        item["details"] = details
    return item


def read_and_check(path: Path, id_column: str, source_column: str,
                   requested_locales: list[str] | None) -> tuple[list[dict[str, Any]], list[str]]:
    """Read a CSV once. Raises OSError/UnicodeError for read failures."""
    if not path.is_file():
        raise OSError("input path is not a regular file")
    size = path.stat().st_size
    if size > MAX_BYTES:
        raise OSError(f"input is {size} bytes; limit is {MAX_BYTES} bytes")

    issues: list[dict[str, Any]] = []
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        # csv defaults to a 128 KiB field. A valid field may be as large as the
        # documented whole-file cap, so lift the parser cap only to that cap.
        csv.field_size_limit(MAX_BYTES)
        reader = csv.reader(handle, strict=True)
        try:
            header = next(reader)
        except StopIteration:
            return [issue("empty_file", "CSV has no header row", 1)], []
        except csv.Error as exc:
            return [issue("malformed_csv", f"CSV parser error: {exc}", 1)], []

        header_end = reader.line_num
        if not header:
            return [issue("empty_header", "CSV header row is empty", 1)], []
        for index, name in enumerate(header):
            if not name.strip():
                issues.append(issue("empty_header", "header name is empty", 1, column=index + 1))
        counts = Counter(header)
        for name, count in counts.items():
            if name and count > 1:
                issues.append(issue("duplicate_header", f"header '{name}' appears {count} times", 1, header=name))
        if any(item["kind"] == "duplicate_header" for item in issues):
            return issues, []

        missing = [name for name in (id_column, source_column) if name not in header]
        if missing:
            for name in missing:
                issues.append(issue("missing_column", f"configured column '{name}' is absent", 1, column=name))
            return issues, []

        locales = requested_locales if requested_locales is not None else [
            name for name in header if name not in {id_column, source_column}
        ]
        for name in locales:
            if name not in header:
                issues.append(issue("missing_column", f"configured locale column '{name}' is absent", 1, column=name))
        if any(item["kind"] == "missing_column" for item in issues):
            return issues, locales

        indices = {name: header.index(name) for name in set([id_column, source_column, *locales])}
        ids: dict[str, int] = {}
        previous_end = header_end
        data_rows = 0
        try:
            for row in reader:
                start_line = previous_end + 1
                previous_end = reader.line_num
                data_rows += 1
                if data_rows > MAX_DATA_ROWS:
                    raise OSError(f"CSV has more than {MAX_DATA_ROWS} data rows; limit exceeded")
                if len(row) != len(header):
                    issues.append(issue("ragged_row", f"row has {len(row)} cells; header has {len(header)}", start_line,
                                        cells=len(row), expected_cells=len(header)))
                    continue
                record_id = row[indices[id_column]].strip()
                if not record_id:
                    issues.append(issue("empty_id", f"'{id_column}' is blank", start_line))
                    continue
                if record_id in ids:
                    issues.append(issue("duplicate_id", f"duplicate {id_column} '{record_id}' (first seen on line {ids[record_id]})",
                                        start_line, id=record_id, first_line=ids[record_id]))
                else:
                    ids[record_id] = start_line
                source = row[indices[source_column]]
                source_tokens = placeholders(source)
                for locale in locales:
                    translated = row[indices[locale]]
                    if not translated.strip():
                        issues.append(issue("blank_translation", f"'{locale}' is blank for id '{record_id}'", start_line,
                                            id=record_id, locale=locale))
                        continue
                    target_tokens = placeholders(translated)
                    if target_tokens != source_tokens:
                        issues.append(issue("placeholder_mismatch",
                                            f"'{locale}' placeholders differ for id '{record_id}'", start_line,
                                            id=record_id, locale=locale,
                                            source_placeholders=dict(sorted(source_tokens.items())),
                                            locale_placeholders=dict(sorted(target_tokens.items()))))
        except csv.Error as exc:
            issues.append(issue("malformed_csv", f"CSV parser error: {exc}", previous_end + 1))
    return issues, locales


def same_file(left: Path, right: Path) -> bool:
    try:
        return os.path.samefile(left, right)
    except OSError:
        return left.resolve() == right.resolve()


def write_json(path: Path, source: Path, payload: dict[str, Any]) -> None:
    if same_file(path, source):
        raise OSError("--json-output must not be the input file (including a link to it)")
    path.parent.mkdir(parents=True, exist_ok=True)
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
    try:
        descriptor = os.open(path, flags, 0o600)
    except FileExistsError as exc:
        raise OSError("--json-output must name a new file; existing paths are refused") from exc
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8", newline="\n") as handle:
            json.dump(payload, handle, indent=2, ensure_ascii=False)
            handle.write("\n")
    except Exception:
        # The descriptor was created exclusively by this call. Remove a partial
        # report rather than leaving output that looks complete.
        try:
            path.unlink()
        except OSError:
            pass
        raise


def render(issues: list[dict[str, Any]], source: Path, locales: list[str]) -> str:
    if not issues:
        locale_text = ", ".join(locales) if locales else "(none)"
        return f"CLEAN: {source} — no issues found; locale columns: {locale_text}"
    lines = [f"ISSUES: {len(issues)} found in {source}"]
    for item in issues:
        where = f"line {item['line']}: " if "line" in item else ""
        lines.append(f"- {where}{item['kind']}: {item['message']}")
    return "\n".join(lines)


def parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Read-only validation for dialogue/localization CSV files.")
    parser.add_argument("input", type=Path, help="UTF-8 CSV file to inspect; it is never modified")
    parser.add_argument("--id-column", default="id", help="ID header (default: id)")
    parser.add_argument("--source-column", default="en", help="source-text header (default: en)")
    parser.add_argument("--locale-columns", help="comma-separated locale headers; default: every other header")
    parser.add_argument("--json-output", type=Path, help="optional JSON report path; must differ from input")
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv if argv is not None else sys.argv[1:])
    locales = None
    if args.locale_columns is not None:
        locales = [name.strip() for name in args.locale_columns.split(",")]
        if not locales or any(not name for name in locales):
            print("ERROR: --locale-columns must be a non-empty comma-separated header list", file=sys.stderr)
            return 2
    try:
        issues, active_locales = read_and_check(args.input, args.id_column, args.source_column, locales)
        if args.json_output:
            write_json(args.json_output, args.input, {
                "input": str(args.input), "id_column": args.id_column, "source_column": args.source_column,
                "locale_columns": active_locales, "issues": issues,
            })
    except (OSError, UnicodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2
    print(render(issues, args.input, active_locales))
    return 1 if issues else 0


if __name__ == "__main__":
    raise SystemExit(main())
