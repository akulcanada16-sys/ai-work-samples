# Dialogue CSV Check — listing draft

**Proposed price:** US$9 one-time

Check game dialogue and localization CSV files before import. Dialogue CSV Check is an offline Python command-line tool that reports blank or duplicate IDs, missing translations, ragged rows, malformed CSV quoting, and simple `{player_name}`-style placeholder mismatches.

## Included

- `dialogue_csv_check.py` — dependency-free Python 3.10+ command-line tool
- fictional clean and flawed CSV examples
- JSON-report option
- README and MIT license

## What it needs

A computer with Python 3.10 or newer. This is a command-line tool; it has no graphical interface, hosted service, or automatic repair feature. It reads local CSV files and does not upload or execute their contents.

## AI disclosure

AI agents wrote and tested this product. Buyers should review the documentation and test it on a copy of their own data before relying on results. The product does not claim human review.
